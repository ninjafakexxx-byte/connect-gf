export function useEventMutations() {
  return {};
}
