export const queryDefaults = {
  staleTime: 1000 * 60,
  gcTime: 1000 * 60 * 5,
  retry: 1,
  refetchOnWindowFocus: false,
};
